function MinChart(a){this._init(a);this.__distinguishBk(a)}
MinChart.prototype={isBk:!1,_yTicks:5,_max:null,_min:null,_timeArr:null,_displayData:null,_pre:null,_xTicks:[[0,"09:30"],[60,"10:30"],[120,"11:30/13:00"],[180,"14:00"],[241,"15:00"]],_upClr:"#FF3232",_eqClr:"#000000",_downClr:"#008300",_lastTime:null,_pushing:null,_closeTime:null,_startTime:"0930",_valArr:null,_turnoverArr:null,_turnoverPriceArr:null,_pointXSpace:"1",_type:"gg",_showDate:null,_timeShareData:null,_dayMap:"星期天,星期一,星期二,星期三,星期四,星期五,星期六".split(","),_parseData:function(a){var a=a[0],b=
this._pointXSpace,c=-1/0,e=1/0,d=[],g=[],h=[],i=[],n=[],l,p,m,q,j,f,r,s,t;q=a.AMOpenTime;j=a.AMCloseTime;f=a.PMOpenTime;r=a.PMCloseTime;l=a.preClosePrice;m=a.dataArray;p=a.stockName;this._showDate=t=a.todayDate;if(!m.length)return this._freshData=!0,this._data;if("1200"==j&&"1300"==f)this._pointXSpace=240/330,this._xTicks=[[0,"09:30"],[240/5.5,"10:30"],[2.5*(240/5.5),"12:00/13:00"],[4*(240/5.5),"14:30"],[241,"16:00"]];if("1200"==j&&"1200"==f)this._pointXSpace=240/330,this._xTicks=[[0,"09:30"],[1.5*
(240/6.5),"11:00"],[3*(240/6.5),"12:30"],[4.5*(240/6.5),"14:00"],[241,"16:00"]];for(var u=f=0,k,o;f<m.length;f++,u++)k=m[f],j=k.t,s=+j,o=""==k.nowp?d.length?d[d.length-1][1]:l:+k.nowp,g.push(j),d.push([u*b,o]),h.push(+o),i.push(+k.n/100),n.push(+k.np);d[0]||d.shift();for(f in d)d[f][0]=+f*b,c=Math.max(c,d[f][1]),e=Math.min(e,d[f][1]);this._valArr=h;this._turnoverArr=i;this._turnoverPriceArr=n;this._lastTime=s;this._closeTime=r;this._pre=l;this._max=c;this._min=e;this._timeArr=g;this._startTime=q;
new ShowStockInfo({sid:this._code,priceArr:h,turnoverArr:i,turnoverPriceArr:n,lastTime:a.dataLastTime,pre:l,max:c,min:e,timeArr:g,todayDate:t,stockName:p});return d},_getYTicksInfo:function(){for(var a=[],b=this._pre,c=Math.max(Math.abs(this._max-b),Math.abs(b-this._min)),c=0==c?0.02:c,e=c/2,d=Number(b)+Number(c),c=Number(b)-Number(c),g=[],h,i=0;i<this._yTicks;i++)h=c+i*e,g.push(h),h<b?a.push(this._downClr):h>b?a.push(this._upClr):a.push(this._eqClr);return{colors:a,ticks:g,max:d,min:c}},_parseOptions:function(){var a=
this._getYTicksInfo();return{series:{color:"#4190ff",lines:{lineWidth:1,overPntRadius:3,overPntColor:"#007cc8",overPntLnWidth:2}},yaxis:{show:!0,max:a.max,min:a.min,tickStyle:"solid",tickColor:"#ebebeb",labelColor:"#666",autoscaleMargin:0,ticks:a.ticks,tickDecimals:2},xaxis:{show:!0,tickStyle:"dotted",tickColor:"#fff",ticks:this._xTicks,max:241,min:0,labelHeight:14,autoscaleMargin:0,autoIndentation:!0},grid:{color:"#666",labelMargin:5,borderWidth:0,clickable:!0,hoverable:!0,showTip:this.bind(this._showTipFn,
this)},legend:{show:!1}}},_showTipFn:function(a,b){var c=b.dataIndex,e=this._data[c];if(e){var d=100*((e[1]-this._pre)/this._pre)+"",g=d.substring(0,d.indexOf(".")+3)+"%";a.show();a[0].innerHTML="<div>"+this.__getTipDate()+'</div><div class="clearfix"><span class="tip-name">时间:</span><span class="tip-value">'+this.__getTipTime(c)+'</span></div><div class="clearfix"><span class="tip-name">当前价:</span><span class="tip-value J_dynColor">'+e[1]+'</span></div><div class="clearfix"><span class="tip-name">涨跌幅:</span><span class="tip-value J_dynColor">'+
g+'</span></div><div class="clearfix"><span class="tip-name">成交量:</span><span class="tip-value">'+this._turnoverArr[c]+"</span></div>";0>d?$(".J_dynColor").addClass("downColor"):0<d&&$(".J_dynColor").addClass("upColor");1130>this._timeArr[c]?Html5Util.translate(a,$(".ctip").parent().width()-$(".ctip").width()-20,0):Html5Util.translate(a,20,0)}},__getTipDate:function(){var a=this._showDate,b=a.substr(0,4),c=a.substr(4,2),a=a.substr(6),e=new Date;e.setFullYear(Number(b),Number(c)-1,Number(a));e=e.getDay();
return b+"/"+c+"/"+a+" 星期"+"日,一,二,三,四,五,六".split(",")[e]},__getTipTime:function(a){var b=this._timeArr[a],a=b.substr(0,2),b=b.substr(2,2);return a+":"+b},draw:function(a){var b=this.__getTodayTime();this._data=null;if(a)for(var c in a)this["_"+c]=a[c];if(!this._date||this._date==b)this._date=b,this._isOpeningDay=!0;this.__distinguishBk(a);this._startTime="0930";var e=this,d=window.setInterval(function(){window.bkhqsdk&&(window.clearInterval(d),e._getData())},10)},_getData:function(){var a=this,b=
new window.bkhqsdk.TimeShareProvider({isKeepingGet:!0,intervalTime:6E4,stockType:"1000",code:[a._code]});b.on("getTodayData",function(b){a._dataLoadComplete(b)});b.on("getSuspensions",function(){});b.getData();this._timeShareData=b},_dataLoadComplete:function(a){BaseChart.draw.apply(this,[a]);this._freshData=!1},__distinguishBk:function(a){if(a&&a.code){var b=a.code;0<=b.indexOf("bk")?this._type="bk":0<=b.indexOf("zs")?this._type="zs":0<=b.indexOf("hk")?(this._pointXSpace=240/330,this._xTicks=[[0,
"09:30"],[240/5.5,"10:30"],[2.5*(240/5.5),"12:00/13:00"],[4*(240/5.5),"14:30"],[241,"16:00"]],this._type="hk"):0<=b.indexOf("usa")?(this._pointXSpace=240/390,this._xTicks=[[0,"09:30"],[1.5*(240/6.5),"11:00"],[3*(240/6.5),"12:30"],[4.5*(240/6.5),"14:00"],[241,"16:00"]],this._type="usa"):this._type="gg";this._numCode=b.replace("sz_","").replace("bk_","").replace("sh_","").replace("zs_","").replace("hk_","").replace("usa_","").replace("fd_","")}if(a&&a.dataUrl)this._dataUrl=a.dataUrl},__getTodayTime:function(){var a=
new Date,b=a.getFullYear()+"",c=this.__add0Before(a.getMonth()+1),a=this.__add0Before(a.getDate());return b+c+a},__add0Before:function(a){a=+a;return 10>a?"0"+a:a+""},clearMe:function(){this._timeShareData.stopGetData();this._startTime=this._timeArr=this._min=this._max=this._pre=this._closeTime=this._lastTime=this._turnoverPriceArr=this._turnoverArr=this._valArr=this._timeShareData=null}};MinChart.prototype=$.extend({},BaseChart,MinChart.prototype);
function FiveMinChart(a){this._init(a);this.__distinguishBk(a)}
FiveMinChart.prototype={isBk:!1,_yTicks:5,_max:null,_min:null,_timeArr:null,_longTimeArr:null,_pre:null,_xTicks:[[0,"-/-"],[48,"-/-"],[96,"-/-"],[144,"-/-"],[192,"-/-"],[241,"-/-"]],_lastTime:null,_pushing:null,_closeTime:"--",_startTime:"--",_valArr:null,_turnoverArr:null,_turnoverPriceArr:null,_dayNumber:"5",_lastPriceArr:null,_showDate:null,_timeShareData5:null,_parseData:function(a){var b=240/(49*this._dayNumber-1),c=a.max,d=a.min,e=[],f=[],p=[],q=[],r=[],s=[],k=[],l,h;l=a.preClosePrice;h=a.data;
a=a.date;if(!h.length)return this._freshData=!0,this._data;k.push(Number(l));for(var g=0;g<h.length-1;g++){var i=h[g].total;k.push(i[i.length-1].nowp)}for(var i=g=0,m;g<h.length;g++){m=h[g].compressed;for(var n=0,j,o;n<m.length;n++,i++)j=m[n],o=+j.nowp,f.push(j.t),p.push(a[g]),e.push([i*b,+o]),q.push(+o),r.push(+j.n/100),s.push(+j.np)}this._valArr=q;this._timeArr=f;this._longTimeArr=p;this._turnoverArr=r;this._lastPriceArr=k;this._turnoverPriceArr=s;this._pre=l;this._max=c;this._min=d;return e},_getYTicksInfo:function(){for(var a=
this._pre,b=Math.max(Math.abs(this._max-a),Math.abs(a-this._min)),b=0==b?0.02:b,c=b/2,d=Number(a)+Number(b),a=Number(a)-Number(b),b=[],e,f=0;f<this._yTicks;f++)e=a+f*c,b.push(e);return{ticks:b,max:d,min:a}},_parseOptions:function(){var a=this._getYTicksInfo();this._getAxisDate();return{series:{color:"#4190ff",lines:{lineWidth:1,overPntRadius:3,overPntColor:"#007cc8",overPntLnWidth:2}},yaxis:{show:!0,max:a.max,min:a.min,tickStyle:"solid",tickColor:"#ebebeb",labelColor:"#666",autoscaleMargin:0,ticks:a.ticks,
tickDecimals:2},xaxis:{show:!0,tickStyle:"dotted",tickColor:"#fff",ticks:this._xTicks,max:241,min:0,labelHeight:14,autoscaleMargin:0,autoIndentation:!0},grid:{color:"#666",labelMargin:5,borderWidth:0,clickable:!0,hoverable:!0,showTip:this.bind(this._showTipFn,this)},legend:{show:!1}}},_showTipFn:function(a,b){var c=b.dataIndex,d=this._data[c];if(d){a.show();var e=this.__getPriceChangeRatio(c);a[0].innerHTML="<div>"+this.__getTipDate(c)+'</div><div class="clearfix"><span class="tip-name">时间:</span><span class="tip-value">'+
this.__getTipTime(c)+'</span></div><div class="clearfix"><span class="tip-name">当前价:</span><span class="tip-value J_dynColor">'+d[1]+'</span></div><div class="clearfix"><span class="tip-name">涨跌幅:</span><span class="tip-value J_dynColor">'+e.pcr+'</span></div><div class="clearfix"><span class="tip-name">成交量:</span><span class="tip-value">'+this._turnoverArr[c]+"</span></div>";0>e.pcrn?$(".J_dynColor").addClass("downColor"):0<e.pcrn&&$(".J_dynColor").addClass("upColor");c<48*this._dayNumber/2?Html5Util.translate(a,
$(".ctip").parent().width()-$(".ctip").width()-20,0):Html5Util.translate(a,20,0)}},__getPriceChangeRatio:function(a){var b=this._lastPriceArr[Math.floor(a/49)],a=100*((this._valArr[a]-b)/b)+"";return{pcr:a.substring(0,a.indexOf(".")+3)+"%",pcrn:a}},__getTipDate:function(a){var b=this._longTimeArr[a],a=b.substr(0,4),c=b.substr(4,2),b=b.substr(6),d=new Date;d.setFullYear(Number(a),Number(c)-1,Number(b));d=d.getDay();return a+"/"+c+"/"+b+" 星期"+"日,一,二,三,四,五,六".split(",")[d]},__getTipTime:function(a){var b=
this._timeArr[a],a=b.substr(0,2),b=b.substr(2,2);return a+":"+b},draw:function(a){var b=this.__getTodayTime();this._data=null;if(a)for(var c in a)this["_"+c]=a[c];if(!this._date||this._date==b)this._date=b,this._isOpeningDay=!0;this.__distinguishBk(a);this._getData()},_getData:function(){var a=this,b=new bkhqsdk.TimeShareProvider({isKeepingGet:!0,intervalTime:5E5,stockType:"1000",code:[a._code],fiveDaysEnable:!0,drawWidth:230});b.on("getTodayData",function(){});b.getFiveDaysTotal(function(b){a._dataLoadComplete(b)});
b.getData();this._timeShareData5=b},_dataLoadComplete:function(a){BaseChart.draw.apply(this,[a]);this._freshData=!1},__distinguishBk:function(a){if(a&&a.code){var b=a.code;this._type=0<=b.indexOf("bk")?"bk":0<=b.indexOf("zs")?"zs":0<=b.indexOf("hk")?"hk":0<=b.indexOf("usa")?"usa":"gg";this._numCode=b.replace("sz_","").replace("bk_","").replace("sh_","").replace("zs_","").replace("hk_","").replace("usa_","").replace("fd_","")}if(a&&a.dataUrl)this._dataUrl=a.dataUrl},_getAxisDate:function(){for(var a=
this._longTimeArr,b=[],c={},d=[],e=a.length,f=0;f<e;f++)c[a[f]]||(c[a[f]]=!0,d.push(a[f]));a=[];for(c=0;c<d.length;c++)a.push([d[c].substr(4,2),d[c].substr(6,2)]);if(6>a.length){c=6-a.length;e=d[d.length-1];for(d=0;d<c;d++)e=this.__getNextDay(e),a.push([e.substr(4,2),e.substr(6,2)])}d=a.length;for(c=0;c<d;c++)b.push([48*c,a[c][0]+"/"+a[c][1]]);this._xTicks=b},__getNextDay:function(a){var b=Number(a.substr(0,4)),c=Number(a.substr(4,2))-1,a=Number(a.substr(6,2)),b=new Date(b,c,a);b.setDate(b.getDate()+
1);for(c=b.getDay();6==c||0==c;)b.setDate(b.getDate()+1),c=b.getDay();c=b.getFullYear()+"";a=this.__add0Before(b.getMonth()+1);b=this.__add0Before(b.getDate());return c+a+b},__getTodayTime:function(){var a=new Date,b=a.getFullYear()+"",c=this.__add0Before(a.getMonth()+1),a=this.__add0Before(a.getDate());return b+c+a},__add0Before:function(a){a=+a;return 10>a?"0"+a:a+""},clearMe:function(){this._timeShareData5.stopGetData();this._startTime=this._timeArr=this._min=this._max=this._pre=this._closeTime=
this._lastTime=this._turnoverPriceArr=this._turnoverArr=this._valArr=this._timeShareData5=null}};FiveMinChart.prototype=$.extend({},BaseChart,FiveMinChart.prototype);
function OpenFund(a){this._init(a);this.__distinguishBk(a)}
OpenFund.prototype={_dataUrl:"http://fund.10jqka.com.cn/bdbkData/",_yTicks:5,_max:null,_min:null,_pre:null,_xTicks:[[0,"-/-"],[241,"-/-"]],_lastTime:null,_startTime:null,_lastPoint:null,_dayNumber:"60",_allData:null,_netData:null,_numCode:null,_timeArr:null,_lNetArr:null,_fNetArr:null,_netArr:null,_init:function(a){var c=this.__getTodayTime();this._data=null;if(a)for(var b in a)this["_"+b]=a[b];if(!this._date||this._date==c)this._date=c,this._isOpeningDay=!0;this._$chart=$("#"+this._id);this.__distinguishBk(a);
this._getData()},_parseData:function(a){var a=a.split("|"),c=240/(this._dayNumber-1),b=-1/0,d=1/0,e=[],f=[],g=[],h=[],j=[],k;k=+this._lastPoint[1];this._pushing&&a.shift();if(!a.length)return this._freshData=!0,this._netData;for(var l=0,m=0,i,n;l<a.length;l++,m++)i=a[l].split(","),n=""==i[1]?e.length?e[e.length-1][1]:k:Number(i[1]).toFixed(4),f.push(i[0]),e.push([m*c,n]),g.push(Number(i[1]).toFixed(4)),h.push(Number(i[2]).toFixed(4)),j.push(Number(i[3]).toFixed(4));this._pushing&&(f=Array.prototype.concat(this._timeArr,
f),e=Array.prototype.concat(this._data,e),g=Array.prototype.concat(this._netArr,g),h=Array.prototype.concat(this._lNetArr,h),j=Array.prototype.concat(this._fNetArr,j));e[0]||e.shift();for(var o in e)b=Math.max(b,e[o][1]),d=Math.min(d,e[o][1]);this._netArr=g;this._lNetArr=h;this._fNetArr=j;this._timeArr=f;this._startTime=f[0];this._lastTime=f[f.length-1];this._pre=k;this._max=b;this._min=d;this._showTopInfo();return e},_getYTicksInfo:function(){for(var a=[],c=this._pre,b=Math.max(Math.abs(this._max-
c),Math.abs(c-this._min)),d=b/2,e=c+b,b=c-b,f=[],g,h=0;h<this._yTicks;h++)g=b+h*d,f.push(g),g<c?a.push(this._downClr):g>c?a.push(this._upClr):a.push(this._eqClr);return{colors:a,ticks:f,max:e,min:b}},_parseOptions:function(){var a=this._getYTicksInfo();this._getAxisDate();return{series:{color:"#4190ff",lines:{lineWidth:1,overPntRadius:3,overPntColor:"#007cc8",overPntLnWidth:2}},yaxis:{show:!0,max:a.max,min:a.min,tickStyle:"solid",tickColor:"#ebebeb",labelColor:"#666",autoscaleMargin:0,ticks:a.ticks,
tickDecimals:2},xaxis:{show:!0,tickStyle:"dotted",tickColor:"#fff",ticks:this._xTicks,max:241,min:0,labelHeight:14,autoscaleMargin:0,autoIndentation:!0},grid:{color:"#666",labelMargin:5,borderWidth:0,clickable:!0,hoverable:!0,showTip:this.bind(this._showTipFn,this)},legend:{show:!1}}},_showTipFn:function(a,c){var b=c.dataIndex,d=this._data[b];if(d){a.show();var e=this.__getLNetChangeRatio(b);a[0].innerHTML="<div>"+this.__getTipDate(b)+'</div><div class="clearfix"><span class="tip-name">当前净值:</span><span class="tip-value J_dqjzColor">'+
d[1]+'</span></div><div class="clearfix"><span class="tip-name">累计净值:</span><span class="tip-value J_ljjzColor">'+this._lNetArr[b]+'</span></div><div class="clearfix"><span class="tip-name">累计涨幅:</span><span class="tip-value J_ljzfColor">'+e.pcr+"</span></div>";0>e.pcrn?$(".J_ljzfColor").addClass("downColor"):0<e.pcrn&&$(".J_ljzfColor").addClass("upColor");d=this.__getLNetChange(b);0>d?$(".J_ljjzColor").addClass("downColor"):0<d&&$(".J_ljjzColor").addClass("upColor");d=this.__getNetChange(b);0>d?
$(".J_dqjzColor").addClass("downColor"):0<d&&$(".J_dqjzColor").addClass("upColor");b<this._dayNumber/2?Html5Util.translate(a,$(".ctip").parent().width()-$(".ctip").width()-20,0):Html5Util.translate(a,20,0)}},__getLNetChangeRatio:function(a){var c=this._fNetArr[a],b=this._lastPoint[3];0<a&&(b=this._fNetArr[a-1]);a=100*((c-b)/b)+"";return{pcr:a.substring(0,a.indexOf(".")+3)+"%",pcrn:a}},__getLNetChange:function(a){var c=this._lNetArr[a],b=this._lastPoint[2];0<a&&(b=this._lNetArr[a-1]);return 100*((c-
b)/b)+""},__getNetChange:function(a){var c=this._data,b=c[a],d=this._lastPoint[1];0<a&&(d=c[a-1][1]);return 100*((b[1]-d)/d)+""},__getTipDate:function(a){var c=this._timeArr[a],a=c.substr(0,4),b=c.substr(4,2),c=c.substr(6),d=new Date;d.setFullYear(Number(a),Number(b)-1,Number(c));d=d.getDay();return a+"/"+b+"/"+c+" 星期"+"日,一,二,三,四,五,六".split(",")[d]},draw:function(a){var c=this._netData,b=c.length;if("1y"==a)this._dayNumber=20;else if("3y"==a)this._dayNumber=60;else if("1n"==a)this._dayNumber=250;
else if("3n"==a)this._dayNumber=750;else if("all"==a)this._dayNumber=b;else return this;a=this._dayNumber;if(b<=a){var d=a-b+1,b=c[0],e;for(e=0;e<d;e++)c.unshift(b)}b=c.length;d=c.slice(b-a);this._lastPoint=c[b-a-1].split(",");c="";for(a=0;a<d.length;a++)c+=d[a]+"|";c=c.slice(0,c.length-1);BaseChart.draw.apply(this,[c]);this._freshData=!1},_getData:function(){var a=this,c=this._getParams();$.getScript(c,function(){a._allData=data;a._netData=data.netStr.split("|");a._showInfo();a.draw("3y")})},_showInfo:function(){var a=
this._allData,c=a.name,b=a.profit,a=b.week,d=b.month,e=b.tmonth,f=b.year,g=b.tyear,b=b.nowyear;$(".J_stockName").text(c);$(".J_rfWeek").text(a+"%");$(".J_rfMonth").text(d+"%");$(".J_rfQuarter").text(e+"%");$(".J_rfYear").text(f+"%");$(".J_rfThisY").text(b+"%");$(".J_rfThreeY").text(g+"%");0<a?$(".J_rfWeek").addClass("upColor"):0>a&&$(".J_rfWeek").addClass("downColor");0<d?$(".J_rfMonth").addClass("upColor"):0>d&&$(".J_rfMonth").addClass("downColor");0<e?$(".J_rfQuarter").addClass("upColor"):0>e&&
$(".J_rfQuarter").addClass("downColor");0<f?$(".J_rfYear").addClass("upColor"):0>f&&$(".J_rfYear").addClass("downColor");0<b?$(".J_rfThisY").addClass("upColor"):0>b&&$(".J_rfThisY").addClass("downColor");0<g?$(".J_rfThreeY").addClass("upColor"):0>g&&$(".J_rfThreeY").addClass("downColor")},_showTopInfo:function(){var a=this._timeArr[this._timeArr.length-1],a=a.substr(0,4)+"-"+a.substr(4,2)+"-"+a.substr(6,2),c=this._netArr[this._netArr.length-1],b=this._netArr[this._netArr.length-2],d=c-b,b=(100*(d/
b)).toFixed(2)+"%",d=d.toFixed(4),e=this._lNetArr[this._lNetArr.length-1];$(".J_currentPrice").text(c);$(".J_riseAndFall").text(d+"("+b+")");$(".J_fundJz").text(e);$(".J_time").text(a)},_getParams:function(){var a=this._dataUrl;return a+=this._numCode+".js"},__distinguishBk:function(a){if(a&&a.code)this._numCode=a.code.replace("fd_","");if(a&&a.dataUrl)this._dataUrl=a.dataUrl},_getAxisDate:function(){var a=this._startTime,c=this._lastTime;this._xTicks=30<this._dayNumber?[[0,a.substr(0,4)+"/"+a.substr(4,
2)],[241,c.substr(0,4)+"/"+c.substr(4,2)]]:[[0,a.substr(4,2)+"/"+a.substr(6,2)],[241,c.substr(4,2)+"/"+c.substr(6,2)]]},__getTodayTime:function(){var a=new Date,c=a.getFullYear()+"",b=this.__add0Before(a.getMonth()+1),a=this.__add0Before(a.getDate());return c+b+a},__add0Before:function(a){a=+a;return 10>a?"0"+a:a+""}};OpenFund.prototype=$.extend({},BaseChart,OpenFund.prototype);
function MonetaryFund(a){this._init(a);this.__distinguishBk(a)}
MonetaryFund.prototype={_dataUrl:"http://fund.10jqka.com.cn/bdbkData/",_yTicks:5,_max:null,_min:null,_pre:null,_xTicks:[[0,"-/-"],[241,"-/-"]],_lastTime:null,_startTime:null,_lastPoint:null,_dayNumber:"60",_allData:null,_netData:null,_numCode:null,_timeArr:null,_perMillionArr:null,_sevenYearArr:null,_dataType:1,_init:function(a){var b=this.__getTodayTime();this._data=null;if(a)for(var c in a)this["_"+c]=a[c];if(!this._date||this._date==b)this._date=b,this._isOpeningDay=!0;this._$chart=$("#"+this._id);
this.__distinguishBk(a);this._getData()},_parseData:function(a){var a=a.split("|"),b=240/(this._dayNumber-1),c=-1/0,d=1/0,e=[],f=[],g=[],h=[],l=Number(this._dataType),j;j=1==this._dataType?+this._lastPoint[1]:+this._lastPoint[2];this._pushing&&a.shift();if(!a.length)return this._freshData=!0,this._netData;for(var k=0,m=0,i,n;k<a.length;k++,m++)i=a[k].split(","),n=""==i[l]?e.length?e[e.length-1][1]:j:Number(i[l]).toFixed(4),f.push(i[0]),e.push([m*b,n]),g.push(Number(i[1]).toFixed(4)),h.push(Number(i[2]).toFixed(4));
this._pushing&&(f=Array.prototype.concat(this._timeArr,f),e=Array.prototype.concat(this._data,e),g=Array.prototype.concat(this._perMillionArr,g),h=Array.prototype.concat(this._sevenYearArr,h));e[0]||e.shift();for(var o in e)c=Math.max(c,e[o][1]),d=Math.min(d,e[o][1]);this._perMillionArr=g;this._sevenYearArr=h;this._timeArr=f;this._startTime=f[0];this._lastTime=f[f.length-1];this._pre=j;this._max=c;this._min=d;this._showTopInfo();return e},_getYTicksInfo:function(){for(var a=[],b=this._pre,c=Math.max(Math.abs(this._max-
b),Math.abs(b-this._min)),d=c/2,e=b+c,c=b-c,f=[],g,h=0;h<this._yTicks;h++)g=c+h*d,f.push(g),g<b?a.push(this._downClr):g>b?a.push(this._upClr):a.push(this._eqClr);return{colors:a,ticks:f,max:e,min:c}},_parseOptions:function(){var a=this._getYTicksInfo();this._getAxisDate();return{series:{color:"#4190ff",lines:{lineWidth:1,overPntRadius:3,overPntColor:"#007cc8",overPntLnWidth:2}},yaxis:{show:!0,max:a.max,min:a.min,tickStyle:"solid",tickColor:"#ebebeb",labelColor:"#666",autoscaleMargin:0,ticks:a.ticks,
tickDecimals:2},xaxis:{show:!0,tickStyle:"dotted",tickColor:"#fff",ticks:this._xTicks,max:241,min:0,labelHeight:14,autoscaleMargin:0,autoIndentation:!0},grid:{color:"#666",labelMargin:5,borderWidth:0,clickable:!0,hoverable:!0,showTip:this.bind(this._showTipFn,this)},legend:{show:!1}}},_showTipFn:function(a,b){var c=b.dataIndex,d=this._data[c];if(d){a.show();var e=1==this._dataType?"每万份收益 :":"七日年化 :",d=1==this._dataType?d[1]:d[1]+"%";a[0].innerHTML="<div>"+this.__getTipDate(c)+'</div><div class="clearfix"><span class="tip-name">'+
e+'</span><span class="tip-value J_dynColor">'+d+"</span></div>";e=this.__getProfitChange(c);0>e?$(".J_dynColor").addClass("downColor"):0<e&&$(".J_dynColor").addClass("upColor");c<this._dayNumber/2?Html5Util.translate(a,$(".ctip").parent().width()-$(".ctip").width()-20,0):Html5Util.translate(a,20,0)}},__getProfitChange:function(a){var b=this._data,c=b[a],d=this._lastPoint[1];0<a&&(d=b[a-1][1]);return 100*((c[1]-d)/d)},__getTipDate:function(a){var b=this._timeArr[a],a=b.substr(0,4),c=b.substr(4,2),
b=b.substr(6),d=new Date;d.setFullYear(Number(a),Number(c)-1,Number(b));d=d.getDay();return a+"/"+c+"/"+b+" 星期"+"日,一,二,三,四,五,六".split(",")[d]},draw:function(a){var b=this._netData,c=b.length;if("wf"==a)this._dataType=1;else if("qr"==a)this._dataType=2;else return this;a=this._dayNumber;if(c<=a){var d=a-c+1,c=b[0],e;for(e=0;e<d;e++)b.unshift(c)}c=b.length;d=b.slice(c-a);this._lastPoint=b[c-a-1].split(",");b="";for(a=0;a<d.length;a++)b+=d[a]+"|";b=b.slice(0,b.length-1);BaseChart.draw.apply(this,[b]);
this._freshData=!1},_getData:function(){var a=this,b=this._getParams();$.getScript(b,function(){a._allData=data;a._netData=data.netStr.split("|");a._showInfo();a.draw("wf")})},_showInfo:function(){var a=this._allData,b=a.name,c=a.profit,a=c.week,d=c.month,e=c.tmonth,f=c.year,g=c.nowyear,c=c.tyear;0<a?$(".J_rfWeek").addClass("upColor"):0>a&&$(".J_rfWeek").addClass("downColor");0<d?$(".J_rfMonth").addClass("upColor"):0>d&&$(".J_rfMonth").addClass("downColor");0<e?$(".J_rfQuarter").addClass("upColor"):
0>e&&$(".J_rfQuarter").addClass("downColor");0<f?$(".J_rfYear").addClass("upColor"):0>f&&$(".J_rfYear").addClass("downColor");0<g?$(".J_rfThisY").addClass("upColor"):0>g&&$(".J_rfThisY").addClass("downColor");0<c?$(".J_rfThreeY").addClass("upColor"):0>c&&$(".J_rfThreeY").addClass("downColor");a=""==a?"--":a+"%";d=""==d?"--":d+"%";e=""==e?"--":e+"%";f=""==f?"--":f+"%";g=""==g?"--":g+"%";c=""==c?"--":c+"%";$(".J_stockName").text(b);$(".J_rfWeek").text(a);$(".J_rfMonth").text(d);$(".J_rfQuarter").text(e);
$(".J_rfYear").text(f);$(".J_rfThisY").text(g);$(".J_rfThreeY").text(c)},_showTopInfo:function(){var a=this._timeArr[this._timeArr.length-1],a=a.substr(0,4)+"-"+a.substr(4,2)+"-"+a.substr(6,2),b=this._perMillionArr[this._perMillionArr.length-1],c=this._sevenYearArr[this._sevenYearArr.length-1]+"%";$(".J_currentPrice").text(b);$(".J_fundJz").text(c);$(".J_time").text(a)},_getParams:function(){var a=this._dataUrl;return a+=this._numCode+".js"},__distinguishBk:function(a){if(a&&a.code)this._numCode=
a.code.replace("fd_","");if(a&&a.dataUrl)this._dataUrl=a.dataUrl},_getAxisDate:function(){var a=this._startTime,b=this._lastTime;this._xTicks=30<this._dayNumber?[[0,a.substr(0,4)+"/"+a.substr(4,2)],[241,b.substr(0,4)+"/"+b.substr(4,2)]]:[[0,a.substr(4,2)+"/"+a.substr(6,2)],[241,b.substr(4,2)+"/"+b.substr(6,2)]]},__getTodayTime:function(){var a=new Date,b=a.getFullYear()+"",c=this.__add0Before(a.getMonth()+1),a=this.__add0Before(a.getDate());return b+c+a},__add0Before:function(a){a=+a;return 10>a?
"0"+a:a+""}};MonetaryFund.prototype=$.extend({},BaseChart,MonetaryFund.prototype);
function MonthChart(a){this._init(a);this.__distinguishBk(a)}
MonthChart.prototype={isBk:!1,_yTicks:5,_max:null,_min:null,_timeArr:null,_longTimeArr:null,_pre:null,_xTicks:[[0,"-/-"],[48,"-/-"],[96,"-/-"],[144,"-/-"],[192,"-/-"],[241,"-/-"]],_lastTime:null,_pushing:null,_closeTime:"--",_startTime:"--",_valArr:null,_turnoverArr:null,_dayNumber:null,_lastPriceArr:null,_showDate:null,_kLineDataObj:null,_parseData:function(a){var b=a.length,c=240/(b-1),d=-1/0,f=1/0,e=[],l=[],m=[],n=[],h=[],i;i=a[0].o;if(!a.length)return this._freshData=!0,this._data;h.push(Number(i));
for(var g=0,o=0;g<a.length;g++,o++){var j=a[g],k=+j.c;l.push(j.t);e.push([o*c,+k]);m.push(+k);n.push(+j.n/100);h.push(+k)}e[0]||e.shift();for(g in e)d=Math.max(d,e[g][1]),f=Math.min(f,e[g][1]);this._valArr=m;this._longTimeArr=this._timeArr=l;this._turnoverArr=n;this._lastPriceArr=h;this._dayNumber=b;this._pre=i;this._max=d;this._min=f;return e},_getYTicksInfo:function(){for(var a=this._pre,b=Math.max(Math.abs(this._max-a),Math.abs(a-this._min)),b=0==b?0.02:b,c=b/2,d=Number(a)+Number(b),a=Number(a)-
Number(b),b=[],f,e=0;e<this._yTicks;e++)f=a+e*c,b.push(f);return{ticks:b,max:d,min:a}},_parseOptions:function(){var a=this._getYTicksInfo();this._getAxisDate();return{series:{color:"#4190ff",lines:{lineWidth:1,overPntRadius:3,overPntColor:"#007cc8",overPntLnWidth:2}},yaxis:{show:!0,max:a.max,min:a.min,tickStyle:"solid",tickColor:"#ebebeb",labelColor:"#666",autoscaleMargin:0,ticks:a.ticks,tickDecimals:2},xaxis:{show:!0,tickStyle:"dotted",tickColor:"#fff",ticks:this._xTicks,max:241,min:0,labelHeight:14,
autoscaleMargin:0,autoIndentation:!0},grid:{color:"#666",labelMargin:5,borderWidth:0,clickable:!0,hoverable:!0,showTip:this.bind(this._showTipFn,this)},legend:{show:!1}}},_showTipFn:function(a,b){var c=b.dataIndex,d=this._data[c];if(d){a.show();var f=this.__getPriceChangeRatio(c);a[0].innerHTML="<div>"+this.__getTipDate(c)+'</div><div class="clearfix"><span class="tip-name">当前价:</span><span class="tip-value J_dynColor">'+d[1]+'</span></div><div class="clearfix"><span class="tip-name">涨跌幅:</span><span class="tip-value J_dynColor">'+
f.pcr+'</span></div><div class="clearfix"><span class="tip-name">成交量:</span><span class="tip-value">'+this._turnoverArr[c]+"</span></div>";0>f.pcrn?$(".J_dynColor").addClass("downColor"):0<f.pcrn&&$(".J_dynColor").addClass("upColor");c<this._dayNumber/2?Html5Util.translate(a,$(".ctip").parent().width()-$(".ctip").width()-20,0):Html5Util.translate(a,20,0)}},__getPriceChangeRatio:function(a){var b=this._lastPriceArr[a],a=100*((this._valArr[a]-b)/b)+"";return{pcr:a.substring(0,a.indexOf(".")+3)+"%",
pcrn:a}},__getTipDate:function(a){var b=this._longTimeArr[a],a=b.substr(0,4),c=b.substr(4,2),b=b.substr(6),d=new Date;d.setFullYear(Number(a),Number(c)-1,Number(b));d=d.getDay();return a+"/"+c+"/"+b+" 星期"+"日,一,二,三,四,五,六".split(",")[d]},draw:function(a){var b=this.__getTodayTime();this._data=null;if(a)for(var c in a)this["_"+c]=a[c];if(!this._date||this._date==b)this._date=b,this._isOpeningDay=!0;this.__distinguishBk(a);this._getData()},_getData:function(){var a=this,b=new bkhqsdk.KLineProvider({isKeepingGet:!0,
historyUrlName:"last31",ma:[5],code:[a._code]});b.on("getFirstGetData",function(b){a._dataLoadComplete(b)});b.getData();this._kLineDataObj=b},_dataLoadComplete:function(a){BaseChart.draw.apply(this,[a]);this._freshData=!1},__distinguishBk:function(a){if(a&&a.code){var b=a.code;this._type=0<=b.indexOf("bk")?"bk":0<=b.indexOf("zs")?"zs":0<=b.indexOf("hk")?"hk":0<=b.indexOf("usa")?"usa":"gg";this._numCode=b.replace("sz_","").replace("bk_","").replace("sh_","").replace("zs_","").replace("hk_","").replace("usa_",
"").replace("fd_","")}if(a&&a.dataUrl)this._dataUrl=a.dataUrl},_getAxisDate:function(){var a=this._longTimeArr,b=a[0],a=a[a.length-1];this._xTicks=[[0,b.substr(0,4)+"/"+b.substr(4,2)+"/"+b.substr(6,2)],[241,a.substr(0,4)+"/"+a.substr(4,2)+"/"+a.substr(6,2)]]},__getTodayTime:function(){var a=new Date,b=a.getFullYear()+"",c=this.__add0Before(a.getMonth()+1),a=this.__add0Before(a.getDate());return b+c+a},__add0Before:function(a){a=+a;return 10>a?"0"+a:a+""},clearMe:function(){this._kLineDataObj.stopGetData();
this._min=this._max=this._pre=this._dayNumber=this._lastPriceArr=this._turnoverArr=this._longTimeArr=this._timeArr=this._valArr=this._kLineDataObj=null}};MonthChart.prototype=$.extend({},BaseChart,MonthChart.prototype);
﻿//@charset "UTF-8";
/**
 * 分时图
 * 使用新接口
 * author:maoheming@myhexin.com
 * */

function YearChart( cfg ) {
    this._init( cfg );
    this.__distinguishBk( cfg );
};

YearChart.prototype = {

    isBk       : false,

    _yTicks    : 5,

    _max       : null,

    _min       : null,

    _timeArr   : null,

    _longTimeArr:null,

    _pre       : null,

    _xTicks : [ [ 0, '-/-' ], [ 48, '-/-' ], [ 96, '-/-' ], [ 144, '-/-' ], [ 192, '-/-' ], [ 241, '-/-' ] ],

    _lastTime  : null,

    _pushing   : null,

    _closeTime : '--',

    _startTime : '--',

    _valArr    : null,

    _turnoverArr    : null,

    _dayNumber : null,

    _lastPriceArr:null,

    _showDate : null,

    _kLineDataObjYear : null,

    _parseData : function( data ) {
        var fullData  = data,
            dataLen   = fullData.length,
            pointXSpace = 240/( dataLen - 1),
            max       = -1 / 0,
            min       =  1 / 0,
            dataFiles = [],
            timeArr   = [],
            priceArr    = [],
            turnoverArr    = [],
            lastPriceArr    = [],
            pre, fenshiData;

        pre           = fullData[0].o;
        fenshiData    = fullData;

        if( !fenshiData.length ){
            this._freshData = true;
            return this._data;
        }

        lastPriceArr.push(Number(pre));

        for( var i = 0, k = 0; i < fenshiData.length; i++,k++ ) {
            var valData   = fenshiData[ i ];
            var val = +valData.c;
            timeArr.push( valData.t );
            dataFiles.push( [ k*pointXSpace, +val ] );
            priceArr.push( +val );
            turnoverArr.push( +valData.n/100 );
            lastPriceArr.push( +val );
        }

        if( !dataFiles[ 0 ] ){
            dataFiles.shift();
        }
        for( var i in dataFiles ) {
            max         = Math.max( max, dataFiles[ i ][ 1 ] );
            min         = Math.min( min, dataFiles[ i ][ 1 ] );
        }
        this._valArr    = priceArr;
        this._timeArr   = timeArr;
        this._longTimeArr   = timeArr;
        this._turnoverArr    = turnoverArr;
        this._lastPriceArr = lastPriceArr;
        this._dayNumber    = dataLen;
        this._pre       = pre;
        this._max       = max;
        this._min       = min;

        return dataFiles;
    },

    _getYTicksInfo : function() {
        var pre    = this._pre,
            dis    = ( this._max - this._min ) / ( this._yTicks - 1 ),
            half   = Math.max( Math.abs( this._max - pre ), Math.abs( pre - this._min ) ),
            half   = (half==0)? 0.02:half,
            step   = half / 2,
            max    = Number(pre) + Number(half),
            min    = Number(pre) - Number(half),
            ticks  = [],
            tick;
        for( var i = 0; i < this._yTicks; i++ ) {
            tick   = min + i * step;
            ticks.push( tick );
        }
        return {
            ticks  : ticks,
            max    : max,
            min    : min
        }
    },

    _parseOptions : function() {
        var yticksInfo = this._getYTicksInfo();
        this._getAxisDate();
        return {
            series : {
                color: '#4190ff',
                lines: {
                    lineWidth     : 1,
                    overPntRadius : 3,
                    overPntColor  : '#007cc8',
                    overPntLnWidth: 2
                }
            },
            yaxis : {
                show           : true,
                max            : yticksInfo.max,
                min            : yticksInfo.min,
                //labelWidth     : 45,
                tickStyle      : 'solid',
                tickColor      : '#ebebeb',
                labelColor     : '#666',
                autoscaleMargin: 0,
                ticks          : yticksInfo.ticks,
                tickDecimals   : 2
            },
            xaxis : {
                show           : true,
                tickStyle      : 'dotted',
                tickColor      : '#fff',
                ticks          : this._xTicks,
                max            : 241,
                min            : 0,
                labelHeight    : 14,
                autoscaleMargin: 0,
                autoIndentation: true
            },
            grid : {
                color       : '#666',
                labelMargin : 5,
                borderWidth : 0,
                clickable   : true,
                hoverable   : true,
                showTip     : this.bind( this._showTipFn, this )
            },
            legend : {
                show: false
            }
        }
    },

    _showTipFn: function( tip, item, pos ) {
        var datas   = this._data;
        var idx     = item.dataIndex;
        var data    = datas[ idx ];
        if( data ) {
            tip.show();
            var priceChangeRatio = this.__getPriceChangeRatio(idx);
            tip[ 0 ].innerHTML = '<div>'+this.__getTipDate(idx)+'</div>' +
                '<div class="clearfix"><span class="tip-name">当前价:</span><span class="tip-value J_dynColor">'+data[ 1 ]+'</span></div>' +
                '<div class="clearfix"><span class="tip-name">涨跌幅:</span><span class="tip-value J_dynColor">'+priceChangeRatio.pcr+'</span></div>' +
                '<div class="clearfix"><span class="tip-name">成交量:</span><span class="tip-value">'+this._turnoverArr[ idx ]+'</span></div>';
            if(priceChangeRatio.pcrn < 0){
                $(".J_dynColor").addClass("downColor");
            }else if(priceChangeRatio.pcrn > 0){
                $(".J_dynColor").addClass("upColor");
            }
            if(idx < (this._dayNumber/2)){
                Html5Util.translate( tip, $(".ctip").parent().width()-$(".ctip").width()-20, 0 );
            }else{
                Html5Util.translate( tip, 20, 0 );
            }
        }
    },
    //涨跌幅计算
    __getPriceChangeRatio: function(idx){
        var datas   = this._valArr;
        var curData    = datas[ idx ];
        var preData = this._lastPriceArr[idx];
        var priceChangeRatioNum = (curData - preData) / preData * 100 +"";
        var priceChangeRatio = priceChangeRatioNum.substring(0,priceChangeRatioNum.indexOf(".") + 3) + "%";

        return {
            pcr:priceChangeRatio,
            pcrn:priceChangeRatioNum
        }
    },

    __getTipDate: function(idx){
        var myDate = this._longTimeArr[idx];
        var year = myDate.substr(0,4);
        var month = myDate.substr(4,2);
        var date = myDate.substr(6);
        var zhDay = ["日","一","二","三","四","五","六" ];
        var thatDate=new Date();
        thatDate.setFullYear(Number(year),Number(month)-1,Number(date));
        var thatDay = thatDate.getDay();
        return year+"/"+month+"/"+date+" 星期"+zhDay[thatDay];
    },

    draw : function( cfg ) {
        var todayTime = this.__getTodayTime();
        this._data = null;
        if( cfg ){
            for( var i in cfg ){
                this[ '_' + i ] = cfg[ i ];
            }
        }
        if( !this._date || ( this._date == todayTime ) ){
            this._date = todayTime;
            this._isOpeningDay = true;
        }
        this.__distinguishBk( cfg );
        this._getData();
    },

    _getData : function( isPush ) {
        var that = this;
        var code = that._code;

        var kLineDataObjYear = new bkhqsdk.KLineProvider({
            isKeepingGet: true,
            historyUrlName:'last365',
            ma:[5],
            code: [code]
        });

        kLineDataObjYear.on('getFirstGetData', function(d) {
            that._dataLoadComplete(d);
        });

        kLineDataObjYear.getData();

        this._kLineDataObjYear = kLineDataObjYear;
    },

    _dataLoadComplete : function( data ) {
        var that = this;
        BaseChart.draw.apply( this, [ data ] );
        this._freshData   = false

    },

    __distinguishBk : function( cfg ) {
        if( cfg && cfg.code ){
            var cfgCode = cfg.code;
            if( cfgCode.indexOf( 'bk' ) >= 0 ) {
                //行业
                this._type = "bk";
            } else if( cfgCode.indexOf( 'zs' ) >= 0 ){
                //指数
                this._type = "zs";
            } else if( cfgCode.indexOf( 'hk' ) >= 0 ){
                //港股
                this._type = "hk";
            } else if( cfgCode.indexOf( 'usa' ) >= 0 ){
                //美股
                this._type = "usa";
            } else {
                //个股
                this._type = "gg";
            }
            this._numCode  = cfgCode.replace( 'sz_', '' ).replace( 'bk_', '' ).replace( 'sh_', '' ).replace( 'zs_', '' ).replace( 'hk_', '' ).replace( 'usa_', '' ).replace( 'fd_', '' );
        }
        if ( cfg && cfg.dataUrl ) {
            this._dataUrl = cfg.dataUrl;
        }
    },

    _getAxisDate : function() {
        var longTime = this._longTimeArr;
        var date1 = longTime[0];
        var date2 = longTime[longTime.length-1];
        if(this._dayNumber > 30){
            this._xTicks = [ [ 0, date1.substr(0,4)+'/'+date1.substr(4,2) ], [ 241, date2.substr(0,4)+'/'+date2.substr(4,2) ] ];
        }else{
            this._xTicks = [ [ 0, date1.substr(4,2)+'/'+date1.substr(6,2) ], [ 241, date2.substr(4,2)+'/'+date2.substr(6,2) ] ];
        }
    },

    /**
     * [__getTodayTime 根据客户端时间获取8位时间]
     * @return {String} [8位时间]
     */
    __getTodayTime : function() {
        var date  = new Date(),
            year  = date.getFullYear() + '',
            month = this.__add0Before( date.getMonth() + 1 ),
            day   = this.__add0Before( date.getDate() );
        return year + month + day;
    },

    __add0Before : function( val ) {
        var res;
        val = +val;
        if( val < 10 ) {
            res = '0' + val;
        } else {
            res = val + '';
        }
        return res;
    },

    clearMe : function(){
        this._kLineDataObjYear.stopGetData();
        this._kLineDataObjYear = null;
        this._valArr           = null;
        this._timeArr          = null;
        this._longTimeArr      = null;
        this._turnoverArr      = null;
        this._lastPriceArr     = null;
        this._dayNumber        = null;
        this._pre              = null;
        this._max              = null;
        this._min              = null;
    }
};

YearChart.prototype = $.extend( {}, BaseChart, YearChart.prototype );
//@charset "UTF-8";
/**
 * Created by maoheming on 2014/10/29.
 */
function ShowStockInfo( data ) {
    this._init( data );
};

ShowStockInfo.prototype = {

    _data : null,

    _type : "gg",

    _sid : null,

    _init : function(data){

        this._sid = data.sid;

        var sid = data.sid;

        this._data = data;

        this._distinguish(sid);

        this._showData();


    },
    _distinguish : function(sid){
        if( sid.indexOf( 'bk' ) >= 0 ) {
            this._dataUrlEnd = "/Header/realHyHeader";//行业
            this._type = "bk";
        } else if( sid.indexOf( 'zs' ) >= 0 ){
            this._dataUrlEnd = "/Header/realCsiHeader";//指数
            this._type = "zs";
        } else if( sid.indexOf( 'hk' ) >= 0 ){
            this._dataUrlPre = "http://stockpage.10jqka.com.cn/";//港股
            this._dataUrlEnd = "/quote/quotation/?";
            this._type = "hk";
        } else if( sid.indexOf( 'usa' ) >= 0 ){
            this._dataUrlPre = "http://stockpage.10jqka.com.cn/";//美股
            this._dataUrlEnd = "/quote/quotation/?";
            this._type = "usa";
        } else {
            this._dataUrlEnd = "/Header/realHeader";//个股
            this._type = "gg";
        }
    },
    _showData : function() {
        var sData = this._getDataItem();
        var todayStartPrice = sData.todayStartPrice;//今开
        var yesterdayEndPrice = sData.yesterdayEndPrice;//昨收
        var maxPrice = sData.maxPrice;//最高
        var minPrice = sData.minPrice;//最低
        var currentPrice = sData.currentPrice;//现价
        var riseAndFallNum = sData.riseAndFallNum;//涨跌额
        var riseAndFall = sData.riseAndFall;//涨跌幅
        var volume = sData.volume;//成交量
        var turnover = sData.turnover;//成交额
        var name = sData.name;//股票名称
        var showTime = sData.showTime;//显示时间

        if(this._type == "usa"){
            $(".J_usaDelete").remove();
            $(".J_bjTime").text(" （美东时间）");
        }else{
            $(".J_bjTime").text(" （北京时间）");
        }

        $(".J_todayStartPrice").text(todayStartPrice);
        $(".J_yesterdayEndPrice").text(yesterdayEndPrice);
        $(".J_maxPrice").text(maxPrice);
        $(".J_minPrice").text(minPrice);
        $(".J_currentPrice").text(currentPrice);
        $(".J_riseAndFall").text(riseAndFallNum+" ("+riseAndFall+")");
        $(".J_volume").text(volume);
        $(".J_turnover").text(turnover);
        $(".J_stockName").text(name);
        $(".J_time").text(showTime);

        if(Number(currentPrice) > Number(yesterdayEndPrice)){
            $(".J_riseAndFall").addClass("upColor");
            $(".J_stockHead").addClass("upColor");
            $(".J_priceIcon").addClass("op-stockdynamic-cur-status-red-up");
        }else if(Number(currentPrice) < Number(yesterdayEndPrice)){
            $(".J_riseAndFall").addClass("downColor");
            $(".J_stockHead").addClass("downColor");
            $(".J_priceIcon").addClass("op-stockdynamic-cur-status-green-down");
        }
        if(Number(todayStartPrice) > Number(yesterdayEndPrice)){
            $(".J_todayStartPrice").addClass("upColor");
        }else if(Number(todayStartPrice) < Number(yesterdayEndPrice)){
            $(".J_todayStartPrice").addClass("downColor");
        }

    },
    _getDataItem : function(){
        var data = this._data;
        var priceArr=data.priceArr ,
            turnoverArr=data.turnoverArr ,
            turnoverPriceArr=data.turnoverPriceArr ,
            timeArr=data.timeArr,
            lastTime=data.lastTime ,
            pre=Number(data.pre) ,
            max=Number(data.max) ,
            min=Number(data.min) ,
            todayDate=data.todayDate,
            stockName=data.stockName;

        var todayStartPrice,yesterdayEndPrice,maxPrice,minPrice,currentPrice,riseAndFallNum,
            riseAndFall,volume,turnover,name,showTime;

        showTime = todayDate.substr(0,4) + "-" + todayDate.substr(4,2) + "-" + todayDate.substr(6);
        showTime += " "+ lastTime.substr(0,2) + ":" + lastTime.substr(2);

        var jk = Number(priceArr[0]);
        var xj = Number(priceArr[priceArr.length-1]);

        var cjl = 0,
            i = 0,
            len = turnoverArr.length;
        for(i = 0; i < len; i++){
            cjl += turnoverArr[i];
        }
        if(cjl>10000){
            cjl = (cjl/10000).toFixed(2)+"万手";
        }else{
            cjl = cjl.toFixed(2)+"手";
        }

        var cje = 0,
            j = 0,
            plen = turnoverPriceArr.length;
        for(j = 0; j < plen; j++){
            cje += turnoverPriceArr[j];
        }
        if(cje>1000000){
            cje = (cje/100000000).toFixed(2)+"亿元";
        }else{
            cje = (cje/10000).toFixed(2)+"万元";
        }

        todayStartPrice = jk.toFixed(2);//今开
        yesterdayEndPrice = pre.toFixed(2);//昨收
        maxPrice = max.toFixed(2);//最高
        minPrice = min.toFixed(2);//最低
        currentPrice = xj.toFixed(2);//现价
        riseAndFallNum = ( xj - pre ).toFixed(2);//涨跌额
        riseAndFall = (riseAndFallNum / pre * 100).toFixed(2) + "%";//涨跌幅
        volume = cjl;//成交量
        turnover = cje;//成交额
        name = stockName;//股票名称

        return {
            todayStartPrice:todayStartPrice,
            yesterdayEndPrice:yesterdayEndPrice,
            maxPrice:maxPrice,
            minPrice:minPrice,
            currentPrice:currentPrice,
            riseAndFallNum:riseAndFallNum,
            riseAndFall:riseAndFall,
            volume:volume,
            turnover:turnover,
            name:name,
            showTime:showTime
        }
    }

};